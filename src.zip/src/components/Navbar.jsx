import { Link } from "react-router-dom";

function Navbar({ carrito, usuario, setUsuario }) {
  return (
    <nav>
      <Link to="/">Inicio</Link>
      <Link to="/carrito">Carrito ({carrito.length})</Link>
      {usuario ? (
        <button onClick={() => setUsuario(null)}>Cerrar sesión</button>
      ) : (
        <Link to="/Login">Login</Link>
      )}
    </nav>
  );
}

export default Navbar;
